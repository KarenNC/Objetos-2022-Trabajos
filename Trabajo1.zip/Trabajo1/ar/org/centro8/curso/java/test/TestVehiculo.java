package org.centro8.curso.java.test;
import org.centro8.curso.java.entities.Vehiculo;
public class TestVehiculo {
    public static void main(String[] args) {
        Vehiculo vehiculo1=new Vehiculo("Ford","Mustang","Negro");
        Vehiculo vehiculo2=new Vehiculo("Ford","Mustang","Negro",78000);
        System.out.println(vehiculo1);
        System.out.println(vehiculo2);

        vehiculo2.setMarca("BMW");
        vehiculo2.setModelo("M3");
        vehiculo2.setColor("Rojo");
        vehiculo2.setPrecio(145000);
        System.out.println(vehiculo2);


    }
}
