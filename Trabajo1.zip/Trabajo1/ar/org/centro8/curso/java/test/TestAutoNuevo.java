package org.centro8.curso.java.test;

import org.centro8.curso.java.entities.AutoNuevo;

public class TestAutoNuevo {
    public static void main(String[] args) {
        
    
    AutoNuevo nuevo1 = new AutoNuevo("Ford", "Mustang", "Negro", "Pioneer");
    AutoNuevo nuevo2 = new AutoNuevo("Ford", "Mustang", "Negro", 78000, "Pioneer");
        System.out.println(nuevo1);
        System.out.println(nuevo2);

        nuevo1.setRadio("Sony");
        System.out.println(nuevo1);

        nuevo2.setMarca("BMW");
        nuevo2.setModelo("M3");
        nuevo2.setColor("Rojo");
        nuevo2.setPrecio(145000);
        System.out.println(nuevo2);

    }
}
