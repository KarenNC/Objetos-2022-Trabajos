package org.centro8.curso.java.test;

import org.centro8.curso.java.entities.Radio;

public class TestRadio {
    public static void main(String[] args) {
        Radio radio1 = new Radio("Pioneer");
        System.out.println(radio1);
    }

}
