package org.centro8.curso.java.entities;

public class Radio {
    private String radio;
    /**
     * Constructor de la clase Raadio
     * @param radio
     */
    public Radio(String radio) {
        this.radio = radio;
    }

    @Override
    public String toString() {
        return "Radio [radio=" + radio + "]";
    }

}
