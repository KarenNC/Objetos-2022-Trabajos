package org.centro8.curso.java.entities;

public class AutoNuevo extends Vehiculo {
    private Radio radio;

    /**
     * Constructor de AutoNuevo sin precio
     * @param marca
     * @param modelo
     * @param color
     * @param radio
     */
    public AutoNuevo(String marca, String modelo, String color, String radio) {
        super(marca, modelo, color);
        this.radio = new Radio(radio);
    }

    /**
     * Constructor de AutoNuevo con precio
     * @param marca
     * @param modelo
     * @param color
     * @param precio
     * @param radio
     */
    public AutoNuevo(String marca, String modelo, String color, double precio, String radio) {
        super(marca, modelo, color, precio);
        this.radio = new Radio(radio);
    }
    /**
     * Este método cambia el objeto Radio por uno nuevo
     * @param radio
     */
    public void setRadio(String radio) {
        this.radio = new Radio(radio);
    }

    @Override
    public String toString() {
        return "AutoNuevo [radio=" + radio + ", " + super.toString() + "]";
    }

}
