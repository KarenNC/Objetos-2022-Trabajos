package org.centro8.curso.java.entities;

public class AutoClasico extends Vehiculo {
    private Radio radio;

    /**
     * Constructor de AutoClasico sin precio
     * @param marca
     * @param modelo
     * @param color
     * @param radio
     */
    public AutoClasico(String marca, String modelo, String color, String radio) {
        super(marca, modelo, color);
        this.radio = new Radio(radio);
    }
    /**
     * Constructor de AutoClasico con precio
     * @param marca
     * @param modelo
     * @param color
     * @param precio
     * @param radio
     */
    public AutoClasico(String marca, String modelo, String color, double precio, String radio) {
        super(marca, modelo, color, precio);
        this.radio = new Radio(radio);
    }
    /**
     * Constructor de AutoClasico sin radio ni precio
     * @param marca
     * @param modelo
     * @param color
     */
    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }
    /**
     * Constructor de AutoClasico sin radio y con precio
     * @param marca
     * @param modelo
     * @param color
     * @param precio
     */
    public AutoClasico(String marca, String modelo, String color, double precio) {
        super(marca, modelo, color, precio);
    }
    /**
     * Este método añade un objeto Radio el cual tiene como parámetro el String radio 
     * @param radio
     */
    public void addRadio(String radio) {
        this.radio = new Radio(radio);
    }

    @Override
    public String toString() {
        return "AutoClasico [radio=" + radio +", "+super.toString()+ "]";
    }
}
