package org.centro8.curso.java.test;

import org.centro8.curso.java.entities.Radio;

public class TestRadio {
    public static void main(String[] args) {
        System.out.println("**************prueba: constructor de Radio****************\n");
        Radio radio1 = new Radio("Pioneer");
        System.out.println(radio1);
    }

}
