package org.centro8.curso.java.entities;

public class Vehiculo {
    private String marca;
    private String modelo;
    private String color;
    private double precio;
    private Radio marcaradio;

    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    public Vehiculo(String marca, String modelo, String color, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

    public Vehiculo(String marca, String modelo, String color, String marcaradio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.marcaradio = new Radio(marcaradio);
    }

    public Vehiculo(String marca, String modelo, String color, double precio, String marcaradio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.marcaradio = new Radio(marcaradio);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void addRadio(String marcaradio) {
        this.marcaradio = new Radio(marcaradio);
    }

    @Override
    public String toString() {
        return "Vehiculo [color=" + color + ", marca=" + marca + ", marcaradio=" + marcaradio + ", modelo=" +
                modelo + ", precio=" + precio + "]";
    }

}
