package org.centro8.curso.java.entities;

public class Radio {
    private String marcaradio;

    /**
     * Constructor de la clase Raadio
     * 
     * @param radio
     */
    public Radio(String marcaradio) {
        this.marcaradio = marcaradio;
    }

    @Override
    public String toString() {
        return "Radio [marcaradio=" + marcaradio + "]";
    }

}
