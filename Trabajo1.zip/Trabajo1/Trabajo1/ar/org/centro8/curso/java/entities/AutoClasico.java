package org.centro8.curso.java.entities;

public class AutoClasico extends Vehiculo {

    public AutoClasico(String marca, String modelo, String color, String marcaradio) {
        super(marca, modelo, color, marcaradio);
    }

    public AutoClasico(String marca, String modelo, String color, double precio, String marcaradio) {
        super(marca, modelo, color, precio, marcaradio);
    }

    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    public AutoClasico(String marca, String modelo, String color, double precio) {
        super(marca, modelo, color, precio);
    }

    @Override
    public String toString() {
        return "AutoClasico: " + super.toString();
    }
}
