package org.centro8.curso.java.test;

import org.centro8.curso.java.entities.Vehiculo;

public class TestVehiculo {
    public static void main(String[] args) {
        Vehiculo vehiculo1 = new Vehiculo("Ford", "Mustang", "Negro");
        Vehiculo vehiculo2 = new Vehiculo("Ford", "Mustang", "Negro", 78000);
        Vehiculo vehiculo3 = new Vehiculo("Ford", "Mustang", "Negro", "Sony");
        Vehiculo vehiculo4 = new Vehiculo("Ford", "Mustang", "Negro", 78000, "Sony");
        System.out.println("**************prueba: constructores de Vehiculo****************\n");
        System.out.println(vehiculo1);
        System.out.println(vehiculo2);
        System.out.println(vehiculo3);
        System.out.println(vehiculo4);

        System.out.println("**************prueba: setters de Vehiculo****************\n");
        vehiculo2.setMarca("BMW");
        vehiculo2.setModelo("M3");
        vehiculo2.setColor("Rojo");
        vehiculo2.setPrecio(145000);
        System.out.println(vehiculo2);
        System.out.println("**************prueba: metodo addRadio****************\n");
        vehiculo2.addRadio("Sony");
        System.out.println(vehiculo2);

    }
}
