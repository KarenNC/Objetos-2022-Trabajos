package org.centro8.curso.java.entities;

public class AutoNuevo extends Vehiculo {

    public AutoNuevo(String marca, String modelo, String color, String marcaradio) {
        super(marca, modelo, color, marcaradio);
    }

    public AutoNuevo(String marca, String modelo, String color, double precio, String marcaradio) {
        super(marca, modelo, color, precio, marcaradio);
    }

    @Override
    public String toString() {
        return "AutoNuevo: " + super.toString();
    }

}
