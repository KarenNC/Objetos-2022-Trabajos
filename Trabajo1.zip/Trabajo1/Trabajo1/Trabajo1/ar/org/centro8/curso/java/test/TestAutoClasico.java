package org.centro8.curso.java.test;

import org.centro8.curso.java.entities.AutoClasico;

public class TestAutoClasico {

    public static void main(String[] args) {

        System.out.println("**************prueba:constructores de AutoClasico****************\n");
        AutoClasico clasico1 = new AutoClasico("Ford", "Taurus", "Verde");
        AutoClasico clasico2 = new AutoClasico("Ford", "Taurus", "Verde", 7900);
        AutoClasico clasico3 = new AutoClasico("Ford", "Taurus", "Verde", "Sony");
        AutoClasico clasico4 = new AutoClasico("Ford", "Taurus", "Verde", 7900, "Sony");

        System.out.println(clasico1);
        System.out.println(clasico2);
        System.out.println(clasico3);
        System.out.println(clasico4);
        System.out.println("**************prueba:metodo addRadio****************\n");
        clasico1.addRadio("Pioneer");
        System.out.println(clasico1);
        System.out.println("**************prueba:setters de AutoClasico****************\n");
        clasico1.setPrecio(7900);
        System.out.println(clasico1);

        clasico2.setMarca("Fiat");
        clasico2.setModelo("600");
        clasico2.setColor("Blanco");
        clasico2.setPrecio(16000);
        System.out.println(clasico2);

    }
}
